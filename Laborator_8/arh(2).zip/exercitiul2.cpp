#include <string.h>
#include <stdio.h>

#include "heap.h"
#include "helpers.h"

void heap_push(binary_heap_t * const heap, const int value) {
}

int heap_top(binary_heap_t const * const heap) {
    return -1;
}

void heap_pop(binary_heap_t * const heap) {

}
