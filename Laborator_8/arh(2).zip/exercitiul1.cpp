#include "exercitiul1.h"

#include <queue>
#include <stdio.h>


void sort_using_pq_heaps(int *values, size_t length) {
}
