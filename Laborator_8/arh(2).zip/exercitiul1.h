#ifndef __EX1_H__
#define __EX1_H__

#include <queue>
#include <stdlib.h>

void sort_using_pq_heaps(int *values, size_t length);


#endif
