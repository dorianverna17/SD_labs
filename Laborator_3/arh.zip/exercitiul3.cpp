#include "helpers.h"
#include "list.h"

node_t *intersection(node_t *n1, node_t *n2) {
  return NULL;
}
