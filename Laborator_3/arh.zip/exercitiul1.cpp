#include <stdio.h>
#include <stdlib.h>

#include "list.h"

void push_front(node_t **x, double data) {
}

void push_back(node_t **x, double data) {
  
}
