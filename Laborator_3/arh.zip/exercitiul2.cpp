#include <stdio.h>
#include <stdlib.h>

#include "list.h"

void map(node_t *x, node_func_t func) {
}

void filter(node_t **x, node_func_t func) {
}

double aggregate(node_t *x, node_func_t func) {

}
