#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>

#include "trie.h"
#include "helpers.h"

void insert(trie_node_t *root, char *str) {

}

bool contains(trie_node_t *root, char *str) {
  return false;
}

void remove(trie_node_t *root, char *str) {

}

char **matchings(trie_node_t *root, char *str) {
  return NULL;
}
