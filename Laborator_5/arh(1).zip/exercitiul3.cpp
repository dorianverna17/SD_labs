#include "helpers.h"
#include "dequeue.h"
#include "list.h"

char *convert_to_postfix(const char *expression) {
  return NULL;
}


int evaluate(const char *postfix_expression) {
  return -1;
}
