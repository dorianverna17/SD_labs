#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "dequeue.h"
#include "helpers.h"

// returneaza a kth cea mai nesemnificativa cifra
// sau 0 daca kth este mai mare decat numarul de cifre
char get_kth_digit(const int number, const char kth) {
  return -1;
}

// sorteaza prin efect lateral vectorul
void radix_sort(int vec[], const size_t length) {

}
