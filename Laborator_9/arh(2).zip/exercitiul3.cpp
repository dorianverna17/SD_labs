#include "helpers.h"
#include "dequeue.h"
#include "undirected_graph.h"

int *shortest_path(undirected_graph_t * const graph,
    const size_t source_id,
    const size_t destination_id) {

    return NULL;
}
