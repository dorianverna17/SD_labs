#include <stdio.h>

#include "dequeue.h"
#include "undirected_graph.h"


void graph_traverse_DFS_recursive(undirected_graph_t * const graph,
    bool * const visited,
    const size_t start_node_id,
    visit_func_t func) {

}


void graph_traverse_DFS_iterative(undirected_graph_t * const graph,
    const size_t start_node_id,
    visit_func_t func) {

}


void graph_traverse_BFS(undirected_graph_t * const graph,
    const size_t start_node_id,
    visit_func_t func) {

}
