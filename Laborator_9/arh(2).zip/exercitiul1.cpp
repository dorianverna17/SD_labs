#include <stdio.h>

#include "undirected_graph.h"

void graph_insert_edge(undirected_graph_t * const graph,
    const size_t source_id,
    const size_t destination_id) {


}

void graph_remove_edge(undirected_graph_t * const graph,
    const size_t source_id,
    const size_t destination_id) {

}

bool graph_is_edge(undirected_graph_t * const graph,
    const size_t source_id,
    const size_t destination_id) {

    return false;
}
