#include "helpers.h"
#include "undirected_graph.h"

size_t connected_componenets(undirected_graph_t *graph) {
    return 0;
}
