#include <vector>
#include <stdio.h>

#include "list.h"
#include "node_weight.h"
#include "weighted_graph.h"


double minimum_spanning_tree(weighted_graph_t *graph) {
}
