#include <math.h>
#include <stdio.h>

#include "weighted_graph.h"
#include "node_weight.h"

vector<weighted_edge_t> graph_get_all_edges(weighted_graph_t *graph) {

}
